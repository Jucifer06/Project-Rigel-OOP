package ch.epfl.rigel.astronomy;

import ch.epfl.rigel.coordinates.EquatorialCoordinates;
import ch.epfl.rigel.math.ClosedInterval;

import java.time.LocalDateTime;
import java.util.Locale;

/**
 * @author Juliette Parchet (295888)
 * @author Paola Matta (296390)
 */
public class Moon extends CelestialObject {

    private final float phase;
    private static final String name = "Lune";

    public Moon(EquatorialCoordinates equatorialPos, float angularSize, float magnitude, float phase) {
        super(name, equatorialPos, angularSize, magnitude);

        ClosedInterval interval = ClosedInterval.of(0, 1);
        if (!(interval.contains(phase))) {
            throw new IllegalArgumentException();
        }
        this.phase = phase;
    }

    @Override
    public String info() {
        return String.format(Locale.ROOT, "%s (%.1f%s)", name(), phase * 100, "%");
    }
}
