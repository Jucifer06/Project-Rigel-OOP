package ch.epfl.rigel.coordinates;

import ch.epfl.rigel.astronomy.Epoch;
import ch.epfl.rigel.math.Angle;
import ch.epfl.rigel.math.Polynomial;

import java.time.ZonedDateTime;
import java.util.function.Function;

/**
 * Ecliptic to equatorial converter
 *
 * @author Juliette Parchet (295888)
 * @author Paola Matta (296390)
 */
public final class EclipticToEquatorialConversion implements Function<EclipticCoordinates, EquatorialCoordinates> {

    private final double cosObliquity, sinObliquity;

    /**
     * Constructor of an ecliptic to equatorial converter for a specific time and zone
     *
     * @param when : a time and zone when the future conversions will take place
     */
    public EclipticToEquatorialConversion(ZonedDateTime when) {
        Polynomial poly = Polynomial.of(Angle.ofArcsec(0.00181),
                Angle.ofArcsec(-0.0006),
                Angle.ofArcsec(-46.815),
                Angle.ofDMS(23, 26, 21.45));
        double T = Epoch.J2000.julianCenturiesUntil(when);
        double obliquity = poly.at(T);
        cosObliquity = Math.cos(obliquity);
        sinObliquity = Math.sin(obliquity);
    }

    @Override
    public EquatorialCoordinates apply(EclipticCoordinates eclipticCoordinates) {
        double lon = eclipticCoordinates.lon();
        double lat = eclipticCoordinates.lat();
        double sinLon = Math.sin(lon);
        double ra = Angle.normalizePositive(Math.atan2(sinLon * cosObliquity - Math.tan(lat) * sinObliquity, Math.cos(lon)));
        double dec = Math.asin(Math.sin(lat) * cosObliquity + Math.cos(lat) * sinObliquity * sinLon);
        return EquatorialCoordinates.of(ra, dec);
    }

    @Override
    public int hashCode() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean equals(Object obj) {
        throw new UnsupportedOperationException();
    }

}
