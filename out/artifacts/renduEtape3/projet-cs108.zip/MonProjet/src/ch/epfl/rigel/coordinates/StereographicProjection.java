package ch.epfl.rigel.coordinates;

import ch.epfl.rigel.math.Angle;

import java.util.Locale;
import java.util.function.Function;

public final class StereographicProjection implements Function<HorizontalCoordinates, CartesianCoordinates> {

    private final double altCenter, sinAltCenter, cosAltCenter, azCenter;

    public StereographicProjection(HorizontalCoordinates center) {
        //HorizontalCoordinates centerCopy = HorizontalCoordinates.of(center.az(), center.alt());

        altCenter = center.alt();
        sinAltCenter = Math.sin(altCenter);
        cosAltCenter = Math.cos(altCenter);
        azCenter = center.az();
    }

    public HorizontalCoordinates inverseApply(CartesianCoordinates xy) {
        double az, alt, x, y, cosC, sinC, rho, rhoSqrt;
        x = xy.x();
        y = xy.y();
        rhoSqrt = x * x + y * y;
        rho = Math.sqrt(rhoSqrt);

        cosC = (1 - rhoSqrt) / (rhoSqrt + 1);
        sinC = (2 * rho) / (rhoSqrt + 1);
        az = Angle.normalizePositive(Math.atan2(x * sinC, rho * cosAltCenter * cosC - y * sinAltCenter * sinC) + azCenter);
        alt = Math.asin(cosC * sinAltCenter + (y * sinC * cosAltCenter) / rho);
        return HorizontalCoordinates.of(Angle.normalizePositive(az), alt);
    }

    public double applyToAngle(double rad) {
        return 2 * Math.tan(rad / 4.0);
    }

    public double circleRadiusForParallel(HorizontalCoordinates parallel) {
        return Math.cos(parallel.lat()) / (Math.sin(parallel.lat()) + sinAltCenter);
    }

    public CartesianCoordinates circleCenterForParallel(HorizontalCoordinates hor) {
        double cy = cosAltCenter / (Math.sin(hor.lat()) + sinAltCenter);
        return CartesianCoordinates.of(0, cy);
    }


    @Override
    public CartesianCoordinates apply(HorizontalCoordinates azAlt) {
        double x, y, d, alt, deltaLanda, sinAlt, cosAlt, cosDeltaLanda;
        alt = azAlt.alt();
        sinAlt = Math.sin(alt);
        cosAlt = Math.cos(alt);
        deltaLanda = azAlt.az() - azCenter;
        cosDeltaLanda = Math.cos(deltaLanda);
        d = 1 / (1 + sinAlt * sinAltCenter + cosAlt * cosAltCenter * cosDeltaLanda);
        x = d * cosAlt * Math.sin(deltaLanda);
        y = d * (sinAlt * cosAltCenter - cosAlt * sinAltCenter * cosDeltaLanda);
        return CartesianCoordinates.of(x, y);
    }

    @Override
    public int hashCode() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean equals(Object obj) {
        throw new UnsupportedOperationException();
    }

    @Override
    public String toString() {
        return String.format(Locale.ROOT, "StereographicProjection (longitude=%.4f[rad], latitude=%.4f[rad])", azCenter, altCenter);
        //return "/n center : longitude = " + azCenter + " and latitude = " + altCenter;
    }
}
