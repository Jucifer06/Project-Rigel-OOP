package ch.epfl.rigel.astronomy;

import ch.epfl.rigel.coordinates.EclipticCoordinates;
import ch.epfl.rigel.coordinates.EclipticToEquatorialConversion;
import ch.epfl.rigel.coordinates.EquatorialCoordinates;
import ch.epfl.rigel.math.Angle;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author Juliette Parchet (295888)
 * @author Paola Matta (296390)
 */
public enum PlanetModel implements CelestialObjectModel<Planet> {

    MERCURY("Mercure", 0.24085, 75.5671, 77.612,
            0.205627, 0.387098, 7.0051, 48.449, 6.74, -0.42),

    VENUS("Vénus", 0.615207, 272.30044, 131.54,
            0.006812, 0.723329, 3.3947, 76.769, 16.92, -4.40),

    EARTH("Terre", 0.999996, 99.556772, 103.2055,
            0.016671, 0.999985, 0, 0, 0, 0),

    MARS("Mars", 1.880765, 109.09646, 336.217,
            0.093348, 1.523689, 1.8497, 49.632, 9.36, -1.52),

    JUPITER("Jupiter", 11.857911, 337.917132, 14.6633,
            0.048907, 5.20278, 1.3035, 100.595, 196.74, -9.40),

    SATURN("Saturne", 29.310579, 172.398316, 89.567,
            0.053853, 9.51134, 2.4873, 113.752, 165.60, -8.88),

    URANUS("Uranus", 84.039492, 271.063148, 172.884833,
            0.046321, 19.21814, 0.773059, 73.926961, 65.80, -7.19),

    NEPTUNE("Neptune", 165.84539, 326.895127, 23.07,
            0.010483, 30.1985, 1.7673, 131.879, 62.20, -6.87);

    private String frenchName;
    private final double revolutionPeriod, lonDegAtJ2010, lonDegAtPerigee, orbitEcc, semiMajorAxis,
            inclinDegAtEcliptic, lonDegOfAscendingNode, angularSecSizeAt1UA, magnitudeAt1UA;

    /**
     * @param frenchName
     * @param revolutionPeriod
     * @param lonDegAtJ2010
     * @param lonDegAtPerigee
     * @param orbitEcc
     * @param semiMajorAxis
     * @param inclinDegAtEcliptic
     * @param lonDegOfAscendingNode
     * @param angularSecSizeAt1UA
     * @param magnitudeAt1UA
     */
    PlanetModel(String frenchName, double revolutionPeriod, double lonDegAtJ2010, double lonDegAtPerigee, double orbitEcc,
                double semiMajorAxis, double inclinDegAtEcliptic, double lonDegOfAscendingNode, double angularSecSizeAt1UA, double magnitudeAt1UA) {

        this.frenchName = frenchName;
        this.revolutionPeriod = revolutionPeriod;
        this.lonDegAtJ2010 = Angle.ofDeg(lonDegAtJ2010);
        this.lonDegAtPerigee = Angle.ofDeg(lonDegAtPerigee);
        this.orbitEcc = orbitEcc;
        this.semiMajorAxis = semiMajorAxis;
        this.inclinDegAtEcliptic = Angle.ofDeg(inclinDegAtEcliptic);
        this.lonDegOfAscendingNode = Angle.ofDeg(lonDegOfAscendingNode);
        this.angularSecSizeAt1UA = Angle.ofArcsec(angularSecSizeAt1UA);
        this.magnitudeAt1UA = magnitudeAt1UA;
    }

    public static List<PlanetModel> ALL = List.of(values());

    //Collections.unmodifiableCollection();

    @Override
    public Planet at(double daysSinceJ2010, EclipticToEquatorialConversion eclipticToEquatorialConversion) {

        double meanAngularSpeedEarthAroundSun = (Angle.TAU / 365.242191);

        //Earth
        double earthMeanAnomaly = meanAngularSpeedEarthAroundSun * (daysSinceJ2010 / EARTH.revolutionPeriod) + EARTH.lonDegAtJ2010 - EARTH.lonDegAtPerigee;
        double earthTrueAnomaly = earthMeanAnomaly + 2 * EARTH.orbitEcc * Math.sin(earthMeanAnomaly);
        double earthRadius = (EARTH.semiMajorAxis * (1 - EARTH.orbitEcc * EARTH.orbitEcc)) / (1 + EARTH.orbitEcc * Math.cos(earthTrueAnomaly));
        double earthLonOrbit = earthTrueAnomaly + EARTH.lonDegAtPerigee;

        //Planet
        double meanAnomaly = meanAngularSpeedEarthAroundSun * (daysSinceJ2010 / revolutionPeriod) + lonDegAtJ2010 - lonDegAtPerigee;
        double trueAnomaly = meanAnomaly + 2 * orbitEcc * Math.sin(meanAnomaly);
        double radius = (semiMajorAxis * (1 - orbitEcc * orbitEcc)) / (1 + orbitEcc * Math.cos(trueAnomaly));
        double lonOrbit = trueAnomaly + lonDegAtPerigee;
        double latEclipticHeliocentric = Math.asin(Math.sin(lonOrbit - lonDegOfAscendingNode) * Math.sin(inclinDegAtEcliptic));
        double projectionRadius = radius * Math.cos(latEclipticHeliocentric);
        double projectionLonOrbit = Math.atan2(Math.sin(lonOrbit - lonDegOfAscendingNode) *
                Math.cos(inclinDegAtEcliptic), Math.cos(lonOrbit - lonDegOfAscendingNode)) + lonDegOfAscendingNode;


        double d = earthLonOrbit - projectionLonOrbit;

        double eclipticGeocentricLon;
        if (semiMajorAxis < EARTH.semiMajorAxis) {
            eclipticGeocentricLon = Angle.TAU / 2 + earthLonOrbit +
                    Math.atan2(projectionRadius * Math.sin(d), earthRadius - projectionRadius * Math.cos(d));
        } else {
            eclipticGeocentricLon = projectionLonOrbit + Math.atan2(earthRadius * Math.sin(-d),
                    projectionRadius - earthRadius * Math.cos(-d));
        }
        double eclipticGeocentricLat = Math.atan2(projectionRadius * Math.tan(latEclipticHeliocentric) *
                Math.sin(eclipticGeocentricLon - projectionLonOrbit), earthRadius * Math.sin(d));

        //angular size
        double rho = Math.sqrt(earthRadius * earthRadius + radius * radius - 2 * earthRadius * radius *
                Math.cos(lonOrbit - earthLonOrbit) * Math.cos(latEclipticHeliocentric));
        double planetAngularSize = angularSecSizeAt1UA / rho;

        //Magnitude
        double phase = (1 + Math.cos(eclipticGeocentricLon - lonOrbit)) / 2;
        double magnitude = magnitudeAt1UA + 5 * Math.log10((radius * rho) / Math.sqrt(phase));

        EclipticCoordinates eclipticCoordinates = EclipticCoordinates.of(eclipticGeocentricLon, eclipticGeocentricLat);
        EquatorialCoordinates equatorialCoordinates = eclipticToEquatorialConversion.apply(eclipticCoordinates);
        return new Planet(frenchName, equatorialCoordinates, (float) planetAngularSize, (float) magnitude);
    }
}
