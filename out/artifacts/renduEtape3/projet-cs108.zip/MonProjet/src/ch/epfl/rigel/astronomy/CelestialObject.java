package ch.epfl.rigel.astronomy;

import ch.epfl.rigel.coordinates.EquatorialCoordinates;

import java.util.Locale;
import java.util.Objects;

/**
 * @author Juliette Parchet (295888)
 * @author Paola Matta (296390)
 */

public abstract class CelestialObject {

    private final String name;
    private final EquatorialCoordinates equatorialPos;
    private final float angularSize;
    private final float magnitude;

    protected CelestialObject(String name, EquatorialCoordinates equatorialPos, float angularSize, float magnitude) {
        if (angularSize < 0) {
            throw new IllegalArgumentException();
        }

        this.name = Objects.requireNonNull(name);
        this.equatorialPos = Objects.requireNonNull(equatorialPos);
        this.angularSize = angularSize;
        this.magnitude = magnitude;
    }


    public String name() {
        return name;
    }

    public EquatorialCoordinates equatorialPos() {
        return EquatorialCoordinates.of(equatorialPos.ra(), equatorialPos.dec());
    }

    public double angularSize() {
        return angularSize;
    }

    public double magnitude() {
        return magnitude;
    }

    public String info() {
        //return String.format(Locale.ROOT, "Celestial Object /n Name: % /n equatorialPos: % right ascension, % declinaison /n Angular Size: % / n Magnitude: %", name, equatorialPos.ra(),equatorialPos.dec(), angularSize, magnitude);
        String Newligne = System.getProperty("line.separator");
        return String.format(Locale.ROOT, "Celestial object" + Newligne + "Name: %s" + Newligne + "Equatorial position: %.1f right ascension, %.1f declinaison" + Newligne + "Angular size: %.1f" + Newligne + "Magnitude: %.1f", name, equatorialPos.ra(), equatorialPos.dec(), angularSize, magnitude);
        //return "Celestial object" + Newligne + "Name: " + name + Newligne + "Equatorial position: " + equatorialPos.ra() + " right ascension, " + equatorialPos.dec() + " declinaison" + Newligne + "Angular Size: " + angularSize + Newligne + "Magnitude: " + magnitude;
    }

    @Override
    public String toString() {
        return info();
    }
}
