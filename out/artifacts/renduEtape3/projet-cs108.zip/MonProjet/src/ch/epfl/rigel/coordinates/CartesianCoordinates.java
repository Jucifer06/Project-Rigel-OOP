package ch.epfl.rigel.coordinates;

import java.util.Locale;

public final class CartesianCoordinates {

    private final double abscissa;
    private final double ordinate;

    private CartesianCoordinates(double x, double y) {
        abscissa = x;
        ordinate = y;
    }

    public static CartesianCoordinates of(double x, double y) {
        return new CartesianCoordinates(x, y);
    }


    public double x() {
        return abscissa;
    }

    public double y() {
        return ordinate;
    }

    @Override
    final public int hashCode() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean equals(Object obj) {
        throw new UnsupportedOperationException();
    }

    @Override
    public String toString() {
        return String.format(Locale.ROOT, "(abscissa=%.4f°, ordinate=%.4f°)", abscissa, ordinate);
    }
}
