package ch.epfl.rigel.astronomy;

import java.util.List;
import java.util.Objects;

/**
 * @author Juliette Parchet (295888)
 * @author Paola Matta (296390)
 */

public final class Asterism {

    private final List<Star> stars;

    public Asterism(List<Star> stars) {
        if (stars.isEmpty()) {
            throw new IllegalArgumentException();
        }
        this.stars = Objects.requireNonNull(stars);
    }

    public List<Star> stars() {
        return List.copyOf(stars);
    }
}
