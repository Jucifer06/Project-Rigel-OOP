package ch.epfl.rigel.astronomy;

import ch.epfl.rigel.coordinates.EquatorialCoordinates;
import ch.epfl.rigel.math.ClosedInterval;

/**
 * @author Juliette Parchet (295888)
 * @author Paola Matta (296390)
 */

public final class Star extends CelestialObject {

    private final int hippercosId;
    private final float colorIndex;


    public Star(int hipparcosId, String name, EquatorialCoordinates equatorialPos, float magnitude, float colorIndex) {
        super(name, equatorialPos, 0, magnitude);

        if (hipparcosId <= 0) {
            throw new IllegalArgumentException();
        }

        if (!(ClosedInterval.of(-0.5, 5.5).contains(colorIndex))) {
            throw new IllegalArgumentException();
        }

        this.hippercosId = hipparcosId;
        this.colorIndex = colorIndex;
    }

    public int hipparcosId() {
        return hippercosId;
    }

    public int colorTemperature() {
        double T = 4600 * (1 / (0.92 * colorIndex) + 1 / (0.92 * colorIndex + 0.62));
        return (int) Math.round(T);
    }
}
