package ch.epfl.rigel.math;

import java.util.Locale;

/**
 * A right open interval
 *
 * @author Juliette Parchet (295888)
 * @author Paola Matta (296390)
 */

public final class RightOpenInterval extends Interval {


    /**
     * Constructor of a right open interval
     *
     * @param lowerBound (smaller than the upper bound)
     * @param upperBound
     */
    protected RightOpenInterval(double lowerBound, double upperBound) {
        super(lowerBound, upperBound);
    }

    /**
     * Creates a right open interval
     *
     * @param low  lower bound of the interval (must be lower than the upper bound)
     * @param high upper bound of the interval
     * @return a right open interval
     * @throws IllegalArgumentException if the lower bound is bigger than the upper bound of the interval
     */

    public static RightOpenInterval of(double low, double high) {
        if (low >= high) {
            throw new IllegalArgumentException();
        }
        return new RightOpenInterval(low, high);
    }

    /**
     * Creates a symmetric right open interval of a given size
     *
     * @param size the size of the interval
     * @return a symmetric right open interval
     */

    public static RightOpenInterval symmetric(double size) {
        if (size <= 0) {
            throw new IllegalArgumentException();
        }
        return new RightOpenInterval(-size / 2, size / 2);
    }

    @Override
    public boolean contains(double v) {
        return v >= this.low() && v < this.high();
    }

    /**
     * Return the reduction of a parameter, according to the interval
     *
     * @param v : parameter
     * @return the reduction of a parameter, according to the interval
     */
    public double reduce(double v) {
        return this.low() + FloorMode(v - this.low(), this.size());
    }

    /**
     * Return the floorMode of two doubles
     *
     * @param x : first parameter
     * @param y : second parameter
     * @return the floorMode of two doubles
     */
    private double FloorMode(double x, double y) {
        return x - y * Math.floor(x / y);
    }

    @Override
    public String toString() {
        return String.format(Locale.ROOT, "[%s,%s[", this.low(), this.high());
    }
}
