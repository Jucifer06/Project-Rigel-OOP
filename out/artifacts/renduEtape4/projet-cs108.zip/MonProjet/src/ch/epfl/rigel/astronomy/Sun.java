package ch.epfl.rigel.astronomy;

import ch.epfl.rigel.coordinates.EclipticCoordinates;
import ch.epfl.rigel.coordinates.EquatorialCoordinates;

import java.util.Objects;

/**
 * the Sun (at a given time)
 *
 * @author Juliette Parchet (295888)
 * @author Paola Matta (296390)
 */
public class Sun extends CelestialObject {

    private final EclipticCoordinates eclipticPos;
    private final float meanAnomaly;
    private static final String name = "Soleil";
    private static final float MAGNITUDE = -26.7f;

    public Sun(EclipticCoordinates eclipticPos, EquatorialCoordinates equatorialPos, float angularSize, float meanAnomaly) {
        super(name, equatorialPos, angularSize, MAGNITUDE);
        this.eclipticPos = Objects.requireNonNull(eclipticPos);
        this.meanAnomaly = meanAnomaly;
    }

    public EclipticCoordinates eclipticPos() {
        return EclipticCoordinates.of(eclipticPos.lon(), eclipticPos.lat());
    }

    public double meanAnomaly() {
        return meanAnomaly;
    }


}
