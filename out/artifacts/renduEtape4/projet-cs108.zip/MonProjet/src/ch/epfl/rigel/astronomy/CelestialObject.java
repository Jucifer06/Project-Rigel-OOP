package ch.epfl.rigel.astronomy;

import ch.epfl.rigel.coordinates.EquatorialCoordinates;

import java.util.List;
import java.util.Locale;
import java.util.Objects;

/**
 * a celestial object
 *
 * @author Juliette Parchet (295888)
 * @author Paola Matta (296390)
 */

public abstract class CelestialObject {

    private final String name;
    private final EquatorialCoordinates equatorialPos;
    private final float angularSize, magnitude;

    /**
     * @param name          : name of the celestial object
     * @param equatorialPos : the equatorial position of the object
     * @param angularSize   : the angular size of the object
     * @param magnitude     : the magnitude of the object
     * @throws : IllegalArgumentException if the angular size is negative
     * @throws : NullPointerException if the name or the equatorial position are null
     */
    protected CelestialObject(String name, EquatorialCoordinates equatorialPos, float angularSize, float magnitude) {
        if (angularSize < 0) {
            throw new IllegalArgumentException();
        }
        this.name = Objects.requireNonNull(name);
        this.equatorialPos = Objects.requireNonNull(equatorialPos);
        this.angularSize = angularSize;
        this.magnitude = magnitude;
    }

    /**
     * Return the name
     *
     * @return : the name
     */
    public String name() {
        return name;
    }

    /**
     * return the equatorial position
     *
     * @return : the equatorial position
     */
    public EquatorialCoordinates equatorialPos() {
        return equatorialPos;
    }

    /**
     * return the angular size
     *
     * @return : the angular size
     */
    public double angularSize() {
        return angularSize;
    }

    /**
     * return the magnitude
     *
     * @return : the magnitude
     */
    public double magnitude() {
        return magnitude;
    }

    /**
     * return a message containing information about hte object
     *
     * @return : a message containing information about hte object
     */
    public String info() {
        String Newline = System.getProperty("line.separator");
        return String.format(Locale.ROOT, "Celestial object" + Newline + "Name: %s" + Newline + "Equatorial position: %.1f right ascension, %.1f declinaison" + Newline + "Angular size: %.1f" + Newline + "Magnitude: %.1f", name, equatorialPos.ra(), equatorialPos.dec(), angularSize, magnitude);
    }

    @Override
    public String toString() {
        return info();
    }
}
