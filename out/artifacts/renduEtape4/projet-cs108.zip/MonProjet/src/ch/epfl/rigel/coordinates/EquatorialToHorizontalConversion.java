package ch.epfl.rigel.coordinates;

import ch.epfl.rigel.astronomy.SiderealTime;
import ch.epfl.rigel.math.Angle;

import java.time.ZonedDateTime;
import java.util.function.Function;

/**
 * @author Juliette Parchet (295888)
 * @author Paola Matta (296390)
 */
public final class EquatorialToHorizontalConversion implements Function<EquatorialCoordinates, HorizontalCoordinates> {

    private final double sinLat, cosLat, sl;

    public EquatorialToHorizontalConversion(ZonedDateTime when, GeographicCoordinates where) {
        sl = SiderealTime.local(when, where);
        double lat = where.lat();
        sinLat = Math.sin(lat);
        cosLat = Math.cos(lat);
    }

    @Override
    public HorizontalCoordinates apply(EquatorialCoordinates equatorialCoordinates) {

        double ra = equatorialCoordinates.ra();
        double H = sl - ra;
        double dec = equatorialCoordinates.dec();
        double sinDec = Math.sin(dec);
        double cosDec = Math.cos(dec);

        double sinHigh = sinDec * sinLat + cosDec * cosLat * Math.cos(H);
        double az = Angle.normalizePositive(Math.atan2(-cosDec * cosLat * Math.sin(H), sinDec - sinLat * sinHigh));
        return HorizontalCoordinates.of(az, Math.asin(sinHigh));
    }

    @Override
    public int hashCode() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean equals(Object obj) {
        throw new UnsupportedOperationException();
    }

}
