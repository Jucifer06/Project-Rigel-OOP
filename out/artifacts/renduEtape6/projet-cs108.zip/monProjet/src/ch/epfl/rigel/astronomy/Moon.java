package ch.epfl.rigel.astronomy;

import ch.epfl.rigel.coordinates.EquatorialCoordinates;
import ch.epfl.rigel.math.ClosedInterval;

import java.util.Locale;

/**
 * The moon
 *
 * @author Juliette Parchet (295888)
 * @author Paola Matta (296390)
 */
public class Moon extends CelestialObject {

    private final float phase;
    private static final String name = "Lune";
    private static final ClosedInterval interval = ClosedInterval.of(0, 1);

    /**
     * Constructor of the moon
     *
     * @param equatorialPos : the equatorial position of the moon
     * @param angularSize   : the angular size of the moon
     * @param magnitude     : the magnitude of the moon
     * @param phase         : the phase of the moon
     * @throws : IllegalArgumentException if the phase is not contained in [0, 1]
     */
    public Moon(EquatorialCoordinates equatorialPos, float angularSize, float magnitude, float phase) {
        super(name, equatorialPos, angularSize, magnitude);

        if (!(interval.contains(phase))) {
            throw new IllegalArgumentException();
        }
        this.phase = phase;
    }

    @Override
    public String info() {
        return String.format(Locale.ROOT, "%s (%.1f%s)", name(), phase * 100, "%");
    }
}
