package ch.epfl.rigel.astronomy;

import ch.epfl.rigel.coordinates.*;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Juliette Parchet (295888)
 * @author Paola Matta (296390)
 */
public class ObservedSky {

    private final CartesianCoordinates sunCart, moonCart;
    private final List<CartesianCoordinates> planetsCart, starsCart;

    private final Sun sun;
    private final Moon moon;
    private final List<Planet> planets;

    private final static List<PlanetModel> PLANET_MODELS = PlanetModel.ALL;

    public ObservedSky(ZonedDateTime when, GeographicCoordinates where, StereographicProjection projection, StarCatalogue catalogue) {
        EclipticToEquatorialConversion eclipticToEquatorialConversion = new EclipticToEquatorialConversion(when);
        EquatorialToHorizontalConversion equatorialToHorizontalConversion = new EquatorialToHorizontalConversion(when, where);

        double daysSinceJ2010 = Epoch.J2010.daysUntil(when);

        //Sun
        sun = SunModel.SUN.at(daysSinceJ2010, eclipticToEquatorialConversion);
        EquatorialCoordinates sunEquatorial = sun.equatorialPos();
        sunCart = projection.apply(equatorialToHorizontalConversion.apply(sunEquatorial));

        //Moon
        moon = MoonModel.MOON.at(daysSinceJ2010, eclipticToEquatorialConversion);
        EquatorialCoordinates moonEquatorial = moon.equatorialPos();
        moonCart = projection.apply(equatorialToHorizontalConversion.apply(moonEquatorial));

        //Planets
        planetsCart = new ArrayList<>();
        planets = new ArrayList<>();
        for (PlanetModel p : PLANET_MODELS) {
            if (!(p == PlanetModel.EARTH)) {
                Planet planet = p.at(daysSinceJ2010, eclipticToEquatorialConversion);
                planets.add(planet);
                EquatorialCoordinates planetEquatorial = planet.equatorialPos();
                planetsCart.add(projection.apply(equatorialToHorizontalConversion.apply(planetEquatorial)));
            }
        }

        //Stars
        starsCart = new ArrayList<>();
        for (Star star : catalogue.stars()) {
            EquatorialCoordinates starEquatorial = star.equatorialPos();
            starsCart.add(projection.apply(equatorialToHorizontalConversion.apply(starEquatorial)));
        }
    }

    public Sun sun() {
        return sun;
    }

    public CartesianCoordinates sunPosition() {
        return sunCart;
    }

    public Moon moon() {
        return moon;
    }

    public CartesianCoordinates moonPosition() {
        return moonCart;
    }

    public List<Planet> planets() {
        return List.copyOf(planets);
    }

    public double[] planetPosition() {
        double[] planetPositions = new double[14];
        for (int i = 0; i < planetPositions.length; i = i + 2) {
            planetPositions[i] = planetsCart.get(i).x();
            planetPositions[i + 1] = planetsCart.get(i).y();
        }
        return planetPositions;
    }
}

