package ch.epfl.rigel.astronomy;

import ch.epfl.rigel.coordinates.EclipticCoordinates;
import ch.epfl.rigel.coordinates.EclipticToEquatorialConversion;
import ch.epfl.rigel.coordinates.EquatorialCoordinates;
import ch.epfl.rigel.math.Angle;

/**
 * a sun model
 *
 * @author Juliette Parchet (295888)
 * @author Paola Matta (296390)
 */
public enum SunModel implements CelestialObjectModel<Sun> {

    SUN;

    private static final double sunLonAtJ2010 = Angle.ofDeg(279.557208);
    private static final double sunLonAtPerigee = Angle.ofDeg(283.112438);
    private static final double orbitEcc = 0.016705;
    private static final double tropicalYear = 365.242191;
    private static final double tetaZero = Angle.ofDeg(0.533128);

    @Override
    public Sun at(double daysSinceJ2010, EclipticToEquatorialConversion eclipticToEquatorialConversion) {
        double meanAnomaly = sunLonAtJ2010 - sunLonAtPerigee + (Angle.TAU * daysSinceJ2010 / tropicalYear);
        double trueAnomaly = meanAnomaly + 2 * orbitEcc * Math.sin(meanAnomaly);
        double sunAngularSize = tetaZero * (1 + orbitEcc * Math.cos(trueAnomaly)) / (1 - orbitEcc * orbitEcc);

        double sunEclipticLon = trueAnomaly + sunLonAtPerigee;
        double sunEclipticLat = 0;

        EclipticCoordinates eclipticCoordinates = EclipticCoordinates.of(
                Angle.normalizePositive(sunEclipticLon), sunEclipticLat);
        EquatorialCoordinates equatorialCoordinates = eclipticToEquatorialConversion.apply(eclipticCoordinates);

        return new Sun(eclipticCoordinates, equatorialCoordinates, (float) sunAngularSize, (float) meanAnomaly);
    }
}
