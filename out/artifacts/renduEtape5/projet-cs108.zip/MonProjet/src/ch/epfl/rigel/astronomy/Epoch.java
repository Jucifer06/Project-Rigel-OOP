package ch.epfl.rigel.astronomy;

import java.time.*;
import java.time.temporal.ChronoUnit;

/**
 * Enumeration of epochs
 *
 * @author Juliette Parchet (295888)
 * @author Paola Matta (296390)
 */
public enum Epoch {

    J2000(ZonedDateTime.of(LocalDate.of(2000, Month.JANUARY, 1), LocalTime.of(12, 0), ZoneOffset.UTC)),
    J2010(ZonedDateTime.of(LocalDate.of(2010, Month.JANUARY, 1).minusDays(1), LocalTime.of(0, 0), ZoneOffset.UTC));

    private ZonedDateTime time;

    /**
     * Constructor of an epoch
     *
     * @param time : indicate the time of the epoch
     */
    Epoch(ZonedDateTime time) {
        this.time = time;
    }

    private final double MILLIS_PER_DAY = 86400000.0;
    private final double MILLIS_PER_JULIAN_CENTURIES = MILLIS_PER_DAY * 36525.0;

    /**
     * Return the number of days until a specific date (and zone)
     *
     * @param when : the date and zone
     * @return : the number of days until a specific date (and zone)
     */
    public double daysUntil(ZonedDateTime when) {
        double t = this.time.until(when, ChronoUnit.MILLIS);
        return t / MILLIS_PER_DAY;
    }

    /**
     * Return the number of julian centuries until a specific date (and zone)
     *
     * @param when : the date and zone
     * @return : the number of julian centuries until a specific date (and zone)
     */
    public double julianCenturiesUntil(ZonedDateTime when) {
        double t = this.time.until(when, ChronoUnit.MILLIS);
        return t / MILLIS_PER_JULIAN_CENTURIES;
    }
}
