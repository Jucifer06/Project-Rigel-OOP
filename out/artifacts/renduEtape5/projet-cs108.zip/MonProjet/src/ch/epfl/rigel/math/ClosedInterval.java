package ch.epfl.rigel.math;

import java.util.Locale;

/**
 * A closed interval
 *
 * @author Juliette Parchet (295888)
 * @author Paola Matta (296390)
 */

public final class ClosedInterval extends Interval {

    /**
     * Constructor of a closed interval with the bounds given
     *
     * @param lowerBound : the lower bound
     * @param upperBound : the upper bound
     */
    private ClosedInterval(double lowerBound, double upperBound) {
        super(lowerBound, upperBound);
    }

    /**
     * Check if the closed interval can be constructed and construct it
     *
     * @param low  lower bound of the interval (must be lower than the upper bound)
     * @param high upper bound of the interval
     * @return a closed interval
     * @throws IllegalArgumentException if the lower bound is bigger or equal to the upper bound of the interval
     */
    public static ClosedInterval of(double low, double high) {
        if (low >= high) {
            throw new IllegalArgumentException();
        }
        return new ClosedInterval(low, high);
    }

    /**
     * Creates a symmetric closed interval of a given size
     *
     * @param size the size of the interval
     * @return a closed interval
     */
    public static ClosedInterval symmetric(double size) {
        if (size <= 0) {
            throw new IllegalArgumentException();
        }
        return new ClosedInterval(-size / 2, size / 2);
    }

    @Override
    public boolean contains(double v) {
        return v >= this.low() && v <= this.high();
    }

    public double clip(double v) {
        double low = this.low();
        double high = this.high();

        if (v <= low) {
            return low;
        } else if (v >= high) {
            return high;
        } else {
            return v;
        }
    }

    @Override
    public String toString() {
        return String.format(Locale.ROOT, "[%s,%s]", this.low(), this.high());
    }
}
