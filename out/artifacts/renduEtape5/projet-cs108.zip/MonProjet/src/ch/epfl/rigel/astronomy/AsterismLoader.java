package ch.epfl.rigel.astronomy;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import static java.nio.charset.StandardCharsets.US_ASCII;

/**
 * @author Juliette Parchet (295888)
 * @author Paola Matta (296390)
 */
public enum AsterismLoader implements StarCatalogue.Loader {

    INSTANCE;

    @Override
    public void load(InputStream inputStream, StarCatalogue.Builder builder) throws IOException {
        try (BufferedReader input = new BufferedReader(new InputStreamReader(inputStream, US_ASCII))) {

            while (input.ready()) {
                String lineString = input.readLine();
                String[] stringTable = lineString.split(",");

                List<Star> starsCatalogue = builder.stars();
                List<Star> starListOfAsterism = new ArrayList<>();

                for (String hipparcosNumber : stringTable) {
                    for (Star star : starsCatalogue) {
                        if (star.hipparcosId() == Integer.parseInt(hipparcosNumber)) {
                            starListOfAsterism.add(star);
                        }
                    }
                }
                builder.addAsterism(new Asterism(starListOfAsterism));
            }
        }
    }
}
