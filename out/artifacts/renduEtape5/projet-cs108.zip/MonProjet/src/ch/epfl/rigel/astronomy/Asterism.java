package ch.epfl.rigel.astronomy;

import java.util.Collections;
import java.util.List;

/**
 * Represent an asterism
 *
 * @author Juliette Parchet (295888)
 * @author Paola Matta (296390)
 */

public final class Asterism {

    private final List<Star> stars;

    /**
     * Constructor of asterism
     *
     * @param stars : a non-null list of stars
     * @throws : IllegalArgumentException if the list is empty
     * @throws : NullPointerException if the list is null
     */
    public Asterism(List<Star> stars) {
        if (stars.isEmpty()) {
            throw new IllegalArgumentException();
        }
        this.stars = Collections.unmodifiableList(stars);
    }

    /**
     * Getter of the star list
     *
     * @return : the star list
     */
    public List<Star> stars() {
        return stars;
    }
}
