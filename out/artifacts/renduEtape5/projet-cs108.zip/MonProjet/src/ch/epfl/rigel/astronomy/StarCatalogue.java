package ch.epfl.rigel.astronomy;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * a star catalogue
 *
 * @author Juliette Parchet (295888)
 * @author Paola Matta (296390)
 */
public final class StarCatalogue {
    private final List<Star> stars;
    private final Map<Asterism, List<Integer>> asterismMap;

    public StarCatalogue(List<Star> stars, List<Asterism> asterisms) {
        asterismMap = new HashMap<>();
        for (Asterism asterism : asterisms) {
            List<Integer> index = new ArrayList<>();
            List<Star> asterismList = asterism.stars();
            for (Star starOfAsterism : asterismList) {
                if (!stars.contains(starOfAsterism)) {
                    throw new IllegalArgumentException();
                }
                index.add(stars.indexOf(starOfAsterism));
            }
            asterismMap.put(asterism, index);
        }
        this.stars = Collections.unmodifiableList(stars);
    }

    public List<Star> stars() {
        return stars;
    }

    public Set<Asterism> asterisms() {
        return asterismMap.keySet();
    }

    public List<Integer> asterismIndices(Asterism asterism) {
        if (!asterismMap.containsKey(asterism)) {
            throw new IllegalArgumentException();
        }
        return asterismMap.get(asterism);
    }


    public static class Builder {

        private List<Star> stars;
        private List<Asterism> asterisms;

        public Builder() {
            stars = new ArrayList<>();
            asterisms = new ArrayList<>();
        }

        public Builder addStar(Star star) {
            stars.add(star);
            return this;
        }

        public List<Star> stars() {
            List<Star> starsCopy = List.copyOf(stars);
            return Collections.unmodifiableList(starsCopy);
        }

        public Builder addAsterism(Asterism asterism) {
            asterisms.add(asterism);
            return this;
        }

        public List<Asterism> asterisms() {
            List<Asterism> asterismsCopy = List.copyOf(asterisms);
            return Collections.unmodifiableList(asterismsCopy);
        }

        //Pas fait !!
        public Builder loadFrom(InputStream inputStream, Loader loader) throws IOException {
            //Lance une exception !!! IOException() en cas erreur entrée sortie
            loader.load(inputStream, this);
            return this;
        }

        public StarCatalogue build() {
            return new StarCatalogue(stars, asterisms);
        }

    }

    public interface Loader {
        public abstract void load(InputStream inputStream, Builder builder) throws IOException;
    }
}
